
# En esta cadena, una pizza puede tener 2 tipos de ingredientes, vegetales y proteicos, y su 
# masa puede ser tradicional o delgada. Dentro de los vegetales, las posibilidades son tomate, 
# aceitunas y champiñones. Dentro de los proteicos, las posibilidades son pollo, vacuno o carne 
# vegetal. 

carnicos_posibles = ['pollo', 'vacuno', 'carne vegetal']
vegetales_posibles = ['tomate', 'aceitunas', 'champiñones']
masas_posibles = ['tradicional', 'delgada']
